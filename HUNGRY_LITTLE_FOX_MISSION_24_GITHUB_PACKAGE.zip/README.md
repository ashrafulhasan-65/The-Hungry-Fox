# HUNGRY LITTLE FOX — Mission 24

C++17 / SDL2 game source. Logical game canvas: 1280×720 (16:9).

## Build on Windows

1. Install Visual Studio 2022 with **Desktop development with C++**.
2. Install CMake and Git.
3. Install vcpkg and set the `VCPKG_ROOT` environment variable.
4. From this folder run:

```powershell
vcpkg install sdl2:x64-windows
cmake -S . -B build -A x64 -DCMAKE_TOOLCHAIN_FILE="$env:VCPKG_ROOT/scripts/buildsystems/vcpkg.cmake"
cmake --build build --config Release
```

The executable is created at `build/Release/HungryLittleFox.exe`.

## GitHub Actions

The workflow at `.github/workflows/windows-build.yml` runs on push to the source/build files or manually via **Actions → Windows Build → Run workflow**. A successful run uploads `Hungry-Little-Fox-Windows.zip` as an artifact.

## Verification status

- Source file included: Mission 24.
- CMake and Windows Actions workflow included.
- This package has **not** been compiled or runtime-tested in this environment. A successful GitHub Actions run is required before calling it a verified Windows build.
