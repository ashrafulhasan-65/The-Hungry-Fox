cmake_minimum_required(VERSION 3.20)
project(HungryLittleFox VERSION 0.24 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

find_package(SDL2 CONFIG REQUIRED)

add_executable(HungryLittleFox fox_mission_24.cpp)
target_link_libraries(HungryLittleFox PRIVATE SDL2::SDL2)

if(TARGET SDL2::SDL2main)
    target_link_libraries(HungryLittleFox PRIVATE SDL2::SDL2main)
endif()

if(WIN32)
    target_link_libraries(HungryLittleFox PRIVATE winmm)
endif()
