#include <SDL2/SDL.h>
#include <algorithm>
#include <array>
#include <cmath>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
using namespace std;

// HUNGRY LITTLE FOX - MISSION 24
// Gameplay input reliability, jump forgiveness and platform landing fixes; previous missions preserved.
// Fixed landscape design canvas: 16:9. The renderer fits this canvas to the device.
const int SW=1280, SH=720, LEVEL_COUNT=5, BERRY_COUNT=5;

struct Color { Uint8 r,g,b,a; };
struct Platform { float x,y,w,h; };
enum class TrapType { THORNS, CANOPY_VINE, SPORE, HOT_LEAVES, MOON_CRYSTAL };
struct Hazard { float x,y,w,h; TrapType type=TrapType::THORNS; };

// A player falling through more than one platform in a frame should land on
// the highest crossed platform that overlaps the fox's horizontal collision box.
bool FindLandingPlatformY(const vector<Platform>& platforms,float playerLeft,float playerRight,
                          float oldFootY,float newFootY,float& landingY){
    bool found=false;
    if(newFootY<oldFootY)return false;
    for(const Platform& p:platforms){
        float top=p.y-8.0f;
        bool overlaps=playerLeft<p.x+p.w&&playerRight>p.x;
        bool crossed=oldFootY<=top&&newFootY>=top;
        if(overlaps&&crossed&&(!found||top<landingY)){
            landingY=top;
            found=true;
        }
    }
    return found;
}

struct Berry { float x,y; bool collected=false; };
struct Particle { float x,y,vx,vy,life,maxLife; Color color; };
struct Fox { float x=180,footY=560,vy=0,animTime=0; bool onGround=true,facingRight=true; };
enum class Theme { GREEN_FOREST,CANOPY,MUSHROOM,AUTUMN,MOONLIGHT };
enum class Scene { MENU,HOW_TO,LEVEL_SELECT,PLAYING,PLAYER_DYING,PAUSED,LEVEL_COMPLETE,GAME_COMPLETE,SETTINGS,TRANSITION };

struct LevelData {
    string name;
    Theme theme=Theme::GREEN_FOREST;
    float worldWidth=3600,groundY=560,denX=3300,checkpointX=1800;
    vector<Platform> platforms;
    vector<Hazard> hazards;
    vector<pair<float,float>> berryPositions;
};

class LevelManager {
    vector<LevelData> levels;
    int currentIndex=0;
public:
    LevelManager() {
        LevelData a;
        a.name="GREEN FOREST"; a.theme=Theme::GREEN_FOREST;
        a.worldWidth=3600; a.groundY=560; a.denX=3300; a.checkpointX=1800;
        a.platforms={{690,455,225,28},{1080,405,220,28},{1510,455,250,28},{1940,390,230,28},{2380,445,260,28},{2870,400,230,28}};
        a.hazards={{900,526,100,34,TrapType::THORNS},{2180,526,110,34,TrapType::THORNS}};
        a.berryPositions={{520,526},{1130,367},{1630,526},{2490,407},{3150,526}};
        levels.push_back(a);

        LevelData b;
        b.name="FOREST CANOPY"; b.theme=Theme::CANOPY;
        b.worldWidth=3900; b.groundY=560; b.denX=3600; b.checkpointX=1950;
        b.platforms={{430,470,210,28},{790,405,210,28},{1160,345,220,28},{1540,410,230,28},{1940,350,220,28},{2320,420,230,28},{2720,360,230,28},{3160,425,220,28}};
        b.hazards={{1120,526,100,34,TrapType::CANOPY_VINE},{2860,526,115,34,TrapType::CANOPY_VINE}};
        b.berryPositions={{530,442},{900,367},{1250,307},{2040,312},{3260,387}};
        levels.push_back(b);

        LevelData c;
        c.name="MUSHROOM VALLEY"; c.theme=Theme::MUSHROOM;
        c.worldWidth=4000; c.groundY=560; c.denX=3700; c.checkpointX=2000;
        c.platforms={{520,460,220,28},{900,390,220,28},{1310,450,230,28},{1730,365,240,28},{2180,430,230,28},{2600,350,240,28},{3100,420,250,28}};
        c.hazards={{1200,526,105,34,TrapType::SPORE},{2750,526,105,34,TrapType::SPORE}};
        c.berryPositions={{590,432},{1000,352},{1400,392},{1820,327},{3280,382}};
        levels.push_back(c);

        LevelData d;
        d.name="AUTUMN WOODS"; d.theme=Theme::AUTUMN;
        d.worldWidth=4200; d.groundY=560; d.denX=3900; d.checkpointX=2100;
        d.platforms={{600,460,210,28},{1000,400,210,28},{1400,340,230,28},{1850,420,210,28},{2260,355,240,28},{2750,430,220,28},{3200,365,240,28},{3600,425,220,28}};
        d.hazards={{1650,526,110,34,TrapType::HOT_LEAVES},{2920,526,110,34,TrapType::HOT_LEAVES}};
        d.berryPositions={{680,432},{1080,372},{1490,302},{2340,317},{3690,392}};
        levels.push_back(d);

        LevelData e;
        e.name="MOONLIGHT FOREST"; e.theme=Theme::MOONLIGHT;
        e.worldWidth=4400; e.groundY=560; e.denX=4100; e.checkpointX=2200;
        e.platforms={{540,455,210,28},{930,390,220,28},{1350,330,220,28},{1780,405,230,28},{2220,340,230,28},{2670,415,230,28},{3120,345,230,28},{3560,410,230,28}};
        e.hazards={{1500,526,105,34,TrapType::MOON_CRYSTAL},{3050,526,115,34,TrapType::MOON_CRYSTAL}};
        e.berryPositions={{610,427},{1010,352},{1440,292},{2300,302},{3650,377}};
        levels.push_back(e);
    }
    int Count() const { return (int)levels.size(); }
    int CurrentIndex() const { return currentIndex; }
    const LevelData& Current() const { return levels[currentIndex]; }
    const LevelData& At(int i) const { return levels.at(i); }
    bool Load(int i) { if(i<0||i>=(int)levels.size())return false;currentIndex=i;return true; }
};

// ---------------- MISSION 14: ROBUST PROGRESS SAVE SYSTEM (PRESERVED) ----------------
// The primary save keeps the Mission 13 filename for compatibility.
// A verified temporary file and a previous-good backup protect progress
// against interrupted writes and damaged save data.
const char* PROGRESS_FILE="hungry_little_fox_progress.txt";
const char* PROGRESS_TEMP_FILE="hungry_little_fox_progress.tmp";
const char* PROGRESS_BACKUP_FILE="hungry_little_fox_progress.bak";
const int MAX_STORED_SCORE=10000000;
const int MAX_STORED_STARS=3;
int CalculateStarRating(float seconds){return seconds<=45.0f?3:(seconds<=75.0f?2:1);}

enum class ProgressLoadState {
    FRESH, LOADED, LEGACY_MIGRATED, RECOVERED_BACKUP, CORRUPT_RESET
};

struct ProgressData {
    int highestUnlocked=0; // Level 1 is index zero and is open by default.
    array<bool,LEVEL_COUNT> completed{};
    array<int,LEVEL_COUNT> bestScore{};
    array<int,LEVEL_COUNT> bestStars{};
    ProgressLoadState loadState=ProgressLoadState::FRESH;
    bool lastSaveSucceeded=true;

    static uint32_t Checksum(const string& data) {
        // FNV-1a 32-bit checksum: detects accidental save-file corruption.
        uint32_t hash=2166136261u;
        for(unsigned char ch:data){hash^=(uint32_t)ch;hash*=16777619u;}
        return hash;
    }

    static bool ReadFile(const char* path,string& data) {
        ifstream in(path,ios::binary);
        if(!in)return false;
        ostringstream buffer;
        buffer<<in.rdbuf();
        if(in.bad())return false;
        data=buffer.str();
        return true;
    }

    static bool ParseIntegerLine(const string& line,int& value) {
        istringstream in(line);
        long long parsed=0;
        string extra;
        if(!(in>>parsed)||(in>>extra))return false;
        if(parsed<(-2147483647LL-1LL)||parsed>2147483647LL)return false;
        value=(int)parsed;
        return true;
    }

    static bool ParseLevelRows(istringstream& in,ProgressData& result,bool hasStars) {
        for(int i=0;i<LEVEL_COUNT;++i){
            string line;
            if(!getline(in,line))return false;
            istringstream row(line);
            int done=0,score=0,stars=0;
            string extra;
            if(!(row>>done>>score))return false;
            if(hasStars){if(!(row>>stars))return false;}
            if(row>>extra)return false;
            if((done!=0&&done!=1)||score<0||score>MAX_STORED_SCORE||stars<0||stars>MAX_STORED_STARS)return false;
            if(!done&&stars!=0)return false;
            result.completed[i]=(done==1);
            result.bestScore[i]=score;
            result.bestStars[i]=stars;
        }
        string extraLine;
        while(getline(in,extraLine)){
            if(extraLine.find_first_not_of(" \t\r")!=string::npos)return false;
        }
        return true;
    }

    static void NormalizeUnlocks(ProgressData& result) {
        // A completed level must never leave its next level locked.
        int required=0;
        for(int i=0;i<LEVEL_COUNT-1;++i)
            if(result.completed[i])required=max(required,i+1);
        result.highestUnlocked=max(result.highestUnlocked,required);
        result.highestUnlocked=max(0,min(LEVEL_COUNT-1,result.highestUnlocked));
    }

    static bool ParseV3(const string& data,ProgressData& result) {
        const string marker="CHECKSUM ";
        size_t checkAt=data.rfind(marker);
        if(checkAt==string::npos||checkAt==0||data[checkAt-1]!='\n')return false;
        string payload=data.substr(0,checkAt);
        string checkLine=data.substr(checkAt);
        istringstream check(checkLine);
        string label,hexValue,extra;
        if(!(check>>label>>hexValue)||label!="CHECKSUM"||(check>>extra)||hexValue.size()!=8)return false;
        uint32_t stored=0;
        istringstream hexIn(hexValue);
        hexIn>>hex>>stored;
        if(hexIn.fail()||!hexIn.eof()||stored!=Checksum(payload))return false;
        istringstream in(payload);
        string line;
        if(!getline(in,line)||line!="HFL_PROGRESS_V3")return false;
        if(!getline(in,line)||!ParseIntegerLine(line,result.highestUnlocked))return false;
        if(result.highestUnlocked<0||result.highestUnlocked>=LEVEL_COUNT)return false;
        if(!ParseLevelRows(in,result,true))return false;
        NormalizeUnlocks(result);
        return true;
    }

    static bool ParseV2(const string& data,ProgressData& result) {
        const string marker="CHECKSUM ";
        size_t checkAt=data.rfind(marker);
        if(checkAt==string::npos||checkAt==0||data[checkAt-1]!='\n')return false;
        string payload=data.substr(0,checkAt);
        string checkLine=data.substr(checkAt);
        istringstream check(checkLine);
        string label,hexValue,extra;
        if(!(check>>label>>hexValue)||label!="CHECKSUM"||(check>>extra)||hexValue.size()!=8)return false;
        uint32_t stored=0;
        istringstream hexIn(hexValue);
        hexIn>>hex>>stored;
        if(hexIn.fail()||!hexIn.eof()||stored!=Checksum(payload))return false;

        istringstream in(payload);
        string line;
        if(!getline(in,line)||line!="HFL_PROGRESS_V2")return false;
        if(!getline(in,line)||!ParseIntegerLine(line,result.highestUnlocked))return false;
        if(result.highestUnlocked<0||result.highestUnlocked>=LEVEL_COUNT)return false;
        if(!ParseLevelRows(in,result,false))return false;
        NormalizeUnlocks(result);
        return true;
    }

    static bool ParseV1(const string& data,ProgressData& result) {
        // Read the exact Mission 13 layout so existing player progress survives.
        istringstream in(data);
        string line;
        if(!getline(in,line)||line!="HFL_PROGRESS_V1")return false;
        if(!getline(in,line)||!ParseIntegerLine(line,result.highestUnlocked))return false;
        if(!ParseLevelRows(in,result,false))return false;
        result.highestUnlocked=max(0,min(LEVEL_COUNT-1,result.highestUnlocked));
        NormalizeUnlocks(result);
        return true;
    }

    static string Serialize(const ProgressData& data) {
        ostringstream body;
        body<<"HFL_PROGRESS_V3\n"<<data.highestUnlocked<<"\n";
        for(int i=0;i<LEVEL_COUNT;++i)
            body<<(data.completed[i]?1:0)<<" "<<data.bestScore[i]<<" "<<data.bestStars[i]<<"\n";
        string payload=body.str();
        ostringstream output;
        output<<payload<<"CHECKSUM "<<hex<<nouppercase<<setw(8)<<setfill('0')<<Checksum(payload)<<"\n";
        return output.str();
    }

    static bool IsValidSave(const string& data) {
        ProgressData parsed;
        return ParseV3(data,parsed)||ParseV2(data,parsed)||ParseV1(data,parsed);
    }

    void ResetToDefaults() {
        highestUnlocked=0;
        completed.fill(false);
        bestScore.fill(0);
        bestStars.fill(0);
    }

    void Load() {
        ResetToDefaults();
        lastSaveSucceeded=true;
        loadState=ProgressLoadState::FRESH;
        string data;
        bool primaryExists=ReadFile(PROGRESS_FILE,data);
        bool primaryWasCorrupt=false;

        if(primaryExists){
            ProgressData candidate;
            if(ParseV3(data,candidate)){
                highestUnlocked=candidate.highestUnlocked;
                completed=candidate.completed;
                bestScore=candidate.bestScore;
                bestStars=candidate.bestStars;
                loadState=ProgressLoadState::LOADED;
                return;
            }
            if(ParseV2(data,candidate)){
                highestUnlocked=candidate.highestUnlocked;
                completed=candidate.completed;
                bestScore=candidate.bestScore;
                bestStars=candidate.bestStars;
                loadState=ProgressLoadState::LEGACY_MIGRATED;
                lastSaveSucceeded=Save();
                return;
            }
            if(ParseV1(data,candidate)){
                highestUnlocked=candidate.highestUnlocked;
                completed=candidate.completed;
                bestScore=candidate.bestScore;
                bestStars=candidate.bestStars;
                loadState=ProgressLoadState::LEGACY_MIGRATED;
                lastSaveSucceeded=Save();
                return;
            }
            primaryWasCorrupt=true;
        }

        string backupData;
        if(ReadFile(PROGRESS_BACKUP_FILE,backupData)){
            ProgressData candidate;
            if(ParseV3(backupData,candidate)||ParseV2(backupData,candidate)||ParseV1(backupData,candidate)){
                highestUnlocked=candidate.highestUnlocked;
                completed=candidate.completed;
                bestScore=candidate.bestScore;
                bestStars=candidate.bestStars;
                loadState=ProgressLoadState::RECOVERED_BACKUP;
                // Repair the primary file. Save() preserves a valid backup when
                // the existing primary is corrupt or unreadable.
                lastSaveSucceeded=Save();
                return;
            }
        }

        loadState=primaryWasCorrupt?ProgressLoadState::CORRUPT_RESET:ProgressLoadState::FRESH;
    }

    bool Save() const {
        const string serialized=Serialize(*this);
        ofstream out(PROGRESS_TEMP_FILE,ios::binary|ios::trunc);
        if(!out){cerr<<"Could not open temporary progress file.\n";return false;}
        out.write(serialized.data(),(streamsize)serialized.size());
        out.flush();
        bool writeOk=out.good();
        out.close();
        if(!writeOk||out.fail()){
            std::remove(PROGRESS_TEMP_FILE);
            cerr<<"Could not finish writing progress file.\n";
            return false;
        }

        // Do not replace a valid save until the new temporary file passes
        // the same parser and checksum validation used during loading.
        string verifyData;
        ProgressData verify;
        if(!ReadFile(PROGRESS_TEMP_FILE,verifyData)||!ParseV3(verifyData,verify)){
            std::remove(PROGRESS_TEMP_FILE);
            cerr<<"Temporary progress file failed verification.\n";
            return false;
        }

        string oldData;
        bool oldExists=ReadFile(PROGRESS_FILE,oldData);
        bool oldIsValid=oldExists&&IsValidSave(oldData);
        bool movedOld=false;
        if(oldExists&&oldIsValid){
            std::remove(PROGRESS_BACKUP_FILE);
            if(std::rename(PROGRESS_FILE,PROGRESS_BACKUP_FILE)!=0){
                std::remove(PROGRESS_TEMP_FILE);
                cerr<<"Could not preserve the previous progress backup.\n";
                return false;
            }
            movedOld=true;
        }else if(oldExists){
            // Keep any known-good backup; discard only the invalid primary.
            if(std::remove(PROGRESS_FILE)!=0){
                std::remove(PROGRESS_TEMP_FILE);
                cerr<<"Could not replace damaged progress file.\n";
                return false;
            }
        }

        if(std::rename(PROGRESS_TEMP_FILE,PROGRESS_FILE)!=0){
            if(movedOld)std::rename(PROGRESS_BACKUP_FILE,PROGRESS_FILE);
            std::remove(PROGRESS_TEMP_FILE);
            cerr<<"Could not install the new progress file.\n";
            return false;
        }
        return true;
    }

    const char* LoadStatusText() const {
        switch(loadState){
            case ProgressLoadState::FRESH:return "NEW PROGRESS";
            case ProgressLoadState::LOADED:return "SAVE LOADED";
            case ProgressLoadState::LEGACY_MIGRATED:return "OLD SAVE MIGRATED";
            case ProgressLoadState::RECOVERED_BACKUP:return "BACKUP RESTORED";
            case ProgressLoadState::CORRUPT_RESET:return "DAMAGED SAVE - NEW PROGRESS";
        }
        return "UNKNOWN SAVE STATE";
    }

    bool IsUnlocked(int i) const { return i>=0&&i<=highestUnlocked; }

    bool Complete(int i,int score,int stars) {
        if(i<0||i>=LEVEL_COUNT)return false;
        completed[i]=true;
        bestScore[i]=max(bestScore[i],max(0,min(MAX_STORED_SCORE,score)));
        bestStars[i]=max(bestStars[i],max(1,min(MAX_STORED_STARS,stars)));
        if(i+1<LEVEL_COUNT)highestUnlocked=max(highestUnlocked,i+1);
        lastSaveSucceeded=Save();
        return lastSaveSucceeded;
    }
};

// ---------------- MISSION 17: PROCEDURAL MUSIC + AUDIO SETTINGS ----------------
const char* AUDIO_CONFIG_FILE="hungry_little_fox_audio.cfg";

class AudioSystem {
    struct Voice { double phase=0; float freq=440,remain=0,duration=0,delay=0,volume=0; bool active=false; };
    SDL_AudioDeviceID device=0;
    SDL_AudioSpec obtained{};
    Voice voices[16];
    bool muted=false;
    int musicVolume=55,sfxVolume=75;
    double musicClock=0.0,musicPhase=0.0,bassPhase=0.0;
    int currentNote=-1;

    static constexpr double TAU=6.2831853071795864769;
    static constexpr float melody[16]={
        523.25f,659.25f,783.99f,659.25f,587.33f,698.46f,783.99f,698.46f,
        523.25f,587.33f,659.25f,523.25f,440.00f,523.25f,587.33f,493.88f
    };
    static void Callback(void* ud,Uint8* stream,int len) {
        AudioSystem* s=(AudioSystem*)ud;
        if(!s||!stream)return;
        memset(stream,0,(size_t)len);
        if(s->obtained.format!=AUDIO_S16SYS||s->obtained.channels!=1)return;
        int16_t* out=(int16_t*)stream;
        int count=len/(int)sizeof(int16_t);
        const double rate=s->obtained.freq>0?s->obtained.freq:22050.0;
        const double dt=1.0/rate;
        for(int i=0;i<count;++i) {
            float mixed=0.0f;
            // A short original forest-inspired loop: soft melody with a lower drone.
            int note=(int)(s->musicClock/0.42)%16;
            if(note!=s->currentNote)s->currentNote=note;
            float freq=melody[note];
            double noteTime=fmod(s->musicClock,0.42);
            float attack=(float)min(1.0,noteTime/0.035);
            float release=(float)min(1.0,(0.42-noteTime)/0.075);
            float envelope=min(attack,release);
            float musicGain=(s->muted?0.0f:(float)s->musicVolume/100.0f)*0.075f;
            float melodyWave=(float)(sin(s->musicPhase)+0.22*sin(s->musicPhase*2.0));
            float bassWave=(float)sin(s->bassPhase);
            mixed+=(melodyWave*envelope*musicGain);
            mixed+=(bassWave*musicGain*0.20f);
            s->musicPhase+=TAU*freq*dt;
            s->bassPhase+=TAU*(freq*0.5)*dt;
            if(s->musicPhase>TAU)s->musicPhase=fmod(s->musicPhase,TAU);
            if(s->bassPhase>TAU)s->bassPhase=fmod(s->bassPhase,TAU);
            s->musicClock+=dt;

            for(auto& v:s->voices) {
                if(!v.active)continue;
                if(v.delay>0){v.delay-=(float)dt;continue;}
                float fade=v.duration>0?max(0.0f,min(1.0f,v.remain/v.duration)):0.0f;
                float gain=s->muted?0.0f:(float)s->sfxVolume/100.0f;
                mixed+=(float)sin(v.phase)*v.volume*fade*gain;
                v.phase+=TAU*v.freq*dt;
                if(v.phase>TAU)v.phase=fmod(v.phase,TAU);
                v.remain-=(float)dt;
                if(v.remain<=0)v.active=false;
            }
            mixed=max(-0.90f,min(0.90f,mixed));
            out[i]=(int16_t)(mixed*32767.0f);
        }
    }
    void SaveConfigUnlocked() const {
        const string temp=string(AUDIO_CONFIG_FILE)+".tmp";
        {
            ofstream out(temp,ios::trunc);
            if(!out)return;
            out<<"HFL_AUDIO_V1\n"<<musicVolume<<"\n"<<sfxVolume<<"\n"<<(muted?1:0)<<"\n";
            out.flush();
            if(!out)return;
        }
        rename(temp.c_str(),AUDIO_CONFIG_FILE);
    }
    void LoadConfig() {
        ifstream in(AUDIO_CONFIG_FILE);
        if(!in)return;
        string magic,extra;
        int mv=55,sv=75,m=0;
        if(!getline(in,magic)||magic!="HFL_AUDIO_V1")return;
        if(!(in>>mv>>sv>>m)||(in>>extra))return;
        if(mv<0||mv>100||sv<0||sv>100||(m!=0&&m!=1))return;
        musicVolume=mv;sfxVolume=sv;muted=(m==1);
    }
public:
    bool Init() {
        LoadConfig();
        if(SDL_InitSubSystem(SDL_INIT_AUDIO)<0)return false;
        SDL_AudioSpec want{};
        want.freq=22050;want.format=AUDIO_S16SYS;want.channels=1;
        want.samples=512;want.callback=Callback;want.userdata=this;
        device=SDL_OpenAudioDevice(nullptr,0,&want,&obtained,0);
        if(!device){SDL_QuitSubSystem(SDL_INIT_AUDIO);return false;}
        SDL_PauseAudioDevice(device,0);
        return true;
    }
    void Tone(float freq,float duration,float volume,float delay=0) {
        if(!device)return;
        SDL_LockAudioDevice(device);
        int slot=-1;
        for(int i=0;i<16;++i)if(!voices[i].active){slot=i;break;}
        if(slot<0)slot=0;
        voices[slot]=Voice{};
        voices[slot].freq=freq;voices[slot].duration=duration;
        voices[slot].remain=duration;voices[slot].volume=volume;
        voices[slot].delay=delay;voices[slot].active=true;
        SDL_UnlockAudioDevice(device);
    }
    void Click(){Tone(620,.045f,.10f);}
    void Jump(){Tone(300,.11f,.14f);Tone(450,.08f,.08f,.035f);}
    void Collect(){Tone(880,.10f,.18f);Tone(1175,.14f,.13f,.065f);}
    void Damage(){Tone(190,.16f,.22f);Tone(115,.22f,.18f,.07f);}
    void Death(){Tone(165,.24f,.22f);Tone(110,.34f,.20f,.18f);}
    void Respawn(){Tone(440,.10f,.10f);Tone(660,.14f,.12f,.08f);}
    void Checkpoint(){Tone(660,.09f,.12f);Tone(880,.11f,.12f,.08f);Tone(1175,.16f,.10f,.17f);}
    void CriticalHealth(){Tone(92,.16f,.12f);Tone(78,.18f,.10f,.20f);}
    void Victory(){Tone(523,.17f,.14f);Tone(659,.17f,.14f,.14f);Tone(784,.20f,.14f,.28f);Tone(1046,.34f,.15f,.45f);}
    void ToggleMute(){
        if(device)SDL_LockAudioDevice(device);
        muted=!muted;SaveConfigUnlocked();
        if(device)SDL_UnlockAudioDevice(device);
    }
    void SetMusicVolume(int value){
        value=max(0,min(100,value));
        if(device)SDL_LockAudioDevice(device);
        musicVolume=value;SaveConfigUnlocked();
        if(device)SDL_UnlockAudioDevice(device);
    }
    void SetSfxVolume(int value){
        value=max(0,min(100,value));
        if(device)SDL_LockAudioDevice(device);
        sfxVolume=value;SaveConfigUnlocked();
        if(device)SDL_UnlockAudioDevice(device);
    }
    void ResetAudio(){
        if(device)SDL_LockAudioDevice(device);
        musicVolume=55;sfxVolume=75;muted=false;SaveConfigUnlocked();
        if(device)SDL_UnlockAudioDevice(device);
    }
    bool IsMuted()const{return muted;}
    int MusicVolume()const{return musicVolume;}
    int SfxVolume()const{return sfxVolume;}
    void Shutdown(){
        if(device){SDL_CloseAudioDevice(device);device=0;}
        SDL_QuitSubSystem(SDL_INIT_AUDIO);
    }
};

// ---------------- DRAWING HELPERS ----------------
void SetColor(SDL_Renderer*r,Color c){SDL_SetRenderDrawColor(r,c.r,c.g,c.b,c.a);}
void Rect(SDL_Renderer*r,int x,int y,int w,int h,Color c){SDL_Rect q{x,y,w,h};SetColor(r,c);SDL_RenderFillRect(r,&q);}
void Outline(SDL_Renderer*r,int x,int y,int w,int h,Color c){SDL_Rect q{x,y,w,h};SetColor(r,c);SDL_RenderDrawRect(r,&q);}
void Ellipse(SDL_Renderer*r,int cx,int cy,int rx,int ry,Color c){if(rx<=0||ry<=0)return;SetColor(r,c);for(int y=-ry;y<=ry;++y){float v=1.0f-(float)(y*y)/(float)(ry*ry);if(v<0)continue;int h=(int)(rx*sqrtf(v));SDL_RenderDrawLine(r,cx-h,cy+y,cx+h,cy+y);}}
void Triangle(SDL_Renderer*r,SDL_Point a,SDL_Point b,SDL_Point c,Color col){SetColor(r,col);SDL_Point p[3]={a,b,c};int minY=min(a.y,min(b.y,c.y)),maxY=max(a.y,max(b.y,c.y));for(int y=minY;y<=maxY;++y){int xs[3],n=0;for(int i=0;i<3;++i){auto p1=p[i],p2=p[(i+1)%3];if(p1.y==p2.y)continue;if(y>=min(p1.y,p2.y)&&y<=max(p1.y,p2.y)){float t=(float)(y-p1.y)/(float)(p2.y-p1.y);xs[n++]=(int)(p1.x+t*(p2.x-p1.x));}}if(n>=2)SDL_RenderDrawLine(r,min(xs[0],xs[1]),y,max(xs[0],xs[1]),y);}}

const unordered_map<char,array<unsigned char,7>>& Font(){static const unordered_map<char,array<unsigned char,7>> f={
{'A',{14,17,17,31,17,17,17}},{'B',{30,17,17,30,17,17,30}},{'C',{14,17,16,16,16,17,14}},{'D',{30,17,17,17,17,17,30}},{'E',{31,16,16,30,16,16,31}},{'F',{31,16,16,30,16,16,16}},{'G',{14,17,16,23,17,17,15}},{'H',{17,17,17,31,17,17,17}},{'I',{14,4,4,4,4,4,14}},{'J',{7,2,2,2,18,18,12}},{'K',{17,18,20,24,20,18,17}},{'L',{16,16,16,16,16,16,31}},{'M',{17,27,21,21,17,17,17}},{'N',{17,25,25,21,19,19,17}},{'O',{14,17,17,17,17,17,14}},{'P',{30,17,17,30,16,16,16}},{'Q',{14,17,17,17,21,18,13}},{'R',{30,17,17,30,20,18,17}},{'S',{15,16,16,14,1,1,30}},{'T',{31,4,4,4,4,4,4}},{'U',{17,17,17,17,17,17,14}},{'V',{17,17,17,17,17,10,4}},{'W',{17,17,17,21,21,21,10}},{'X',{17,17,10,4,10,17,17}},{'Y',{17,17,10,4,4,4,4}},{'Z',{31,1,2,4,8,16,31}},
{'0',{14,17,19,21,25,17,14}},{'1',{4,12,4,4,4,4,14}},{'2',{14,17,1,2,4,8,31}},{'3',{30,1,1,14,1,1,30}},{'4',{2,6,10,18,31,2,2}},{'5',{31,16,16,30,1,1,30}},{'6',{14,16,16,30,17,17,14}},{'7',{31,1,2,4,8,8,8}},{'8',{14,17,17,14,17,17,14}},{'9',{14,17,17,15,1,1,14}},{'/',{1,2,2,4,8,8,16}},{':',{0,4,4,0,4,4,0}},{'-',{0,0,0,31,0,0,0}}};return f;}
int TextWidth(const string&s,int z){return (int)s.size()*6*z-(s.empty()?0:z);}
void Text(SDL_Renderer*r,const string&s,int x,int y,int z,Color c){SetColor(r,c);int cur=x;for(char raw:s){char ch=(char)toupper((unsigned char)raw);auto it=Font().find(ch);if(it!=Font().end())for(int row=0;row<7;++row)for(int col=0;col<5;++col)if(it->second[row]&(1<<(4-col))){SDL_Rect px{cur+col*z,y+row*z,z,z};SDL_RenderFillRect(r,&px);}cur+=6*z;}}
void CenterText(SDL_Renderer*r,const string&s,int cx,int y,int z,Color c){Text(r,s,cx-TextWidth(s,z)/2,y,z,c);}
bool Inside(int x,int y,SDL_Rect q){return x>=q.x&&x<q.x+q.w&&y>=q.y&&y<q.y+q.h;}
void Button(SDL_Renderer*r,SDL_Rect b,const string&s,bool hot=false){Rect(r,b.x+4,b.y+5,b.w,b.h,{13,29,24,100});Rect(r,b.x,b.y,b.w,b.h,hot?Color{224,151,55,255}:Color{50,105,70,255});Outline(r,b.x,b.y,b.w,b.h,{255,225,167,255});CenterText(r,s,b.x+b.w/2,b.y+(b.h-21)/2,3,{255,247,221,255});}
void Panel(SDL_Renderer*r,int x,int y,int w,int h){Rect(r,0,0,SW,SH,{10,24,20,155});Rect(r,x+5,y+7,w,h,{5,18,14,130});Rect(r,x,y,w,h,{35,72,51,248});Outline(r,x,y,w,h,{255,222,151,255});Outline(r,x+8,y+8,w-16,h-16,{131,181,103,255});}

// ---------------- WORLD ART ----------------
void Cloud(SDL_Renderer*r,int x,int y,float s){Color c{244,250,250,240};Ellipse(r,x+(int)(32*s),y,(int)(34*s),(int)(17*s),c);Ellipse(r,x+(int)(63*s),y-(int)(9*s),(int)(29*s),(int)(24*s),c);Ellipse(r,x+(int)(94*s),y,(int)(36*s),(int)(17*s),c);Rect(r,x+(int)(17*s),y-(int)(5*s),(int)(112*s),(int)(22*s),c);}
void Mountain(SDL_Renderer*r,int x,int base,int w,int h,Theme t){Color c={127,174,190,255};if(t==Theme::AUTUMN)c={170,130,104,255};if(t==Theme::MOONLIGHT)c={67,94,132,255};if(t==Theme::MUSHROOM)c={111,140,165,255};Triangle(r,{x,base},{x+w/2,base-h},{x+w,base},c);Triangle(r,{x+w/2,base-h},{x+w/2-w/8,base-h/2},{x+w/2,base-h/3},{205,225,222,255});}
void Tree(SDL_Renderer*r,int x,int ground,float s,Theme t){Color a={42,111,68,255},b={48,139,77,255},c={91,174,91,255};if(t==Theme::AUTUMN){a={151,73,42,255};b={204,112,49,255};c={238,168,67,255};}if(t==Theme::MOONLIGHT){a={37,66,91,255};b={51,89,119,255};c={91,131,153,255};}if(t==Theme::MUSHROOM){a={73,89,105,255};b={93,117,132,255};c={137,162,157,255};}int tw=(int)(23*s),th=(int)(104*s);Rect(r,x-tw/2,ground-th,tw,th,{111,72,43,255});Ellipse(r,x,ground-(int)(th+55*s),(int)(54*s),(int)(62*s),a);Ellipse(r,x-(int)(31*s),ground-(int)(th+22*s),(int)(42*s),(int)(42*s),b);Ellipse(r,x+(int)(32*s),ground-(int)(th+23*s),(int)(43*s),(int)(43*s),c);Ellipse(r,x-(int)(4*s),ground-(int)(th+76*s),(int)(32*s),(int)(29*s),c);}
void Background(SDL_Renderer*r,float cam,Theme t){Color sky={119,195,235,255},sun={255,226,132,255},hill={112,177,116,255};if(t==Theme::CANOPY)hill={86,155,105,255};if(t==Theme::MUSHROOM){sky={125,160,195,255};sun={235,208,159,255};hill={91,137,128,255};}if(t==Theme::AUTUMN){sky={241,190,135,255};sun={255,218,138,255};hill={171,111,69,255};}if(t==Theme::MOONLIGHT){sky={35,55,91,255};sun={224,229,226,255};hill={49,92,104,255};}SetColor(r,sky);SDL_RenderClear(r);Ellipse(r,1080,115,44,44,sun);float cs=fmodf(cam*.12f,1500);if(t!=Theme::MOONLIGHT){Cloud(r,(int)(120-cs),155,1);Cloud(r,(int)(650-cs),105,.8f);Cloud(r,(int)(1160-cs),190,.7f);}else for(int i=0;i<22;++i)Ellipse(r,(i*173+37)%SW,(i*97+29)%390,2,2,{235,238,222,220});float ms=fmodf(cam*.2f,1400);for(int i=-1;i<3;++i){int x=(int)(i*1400-ms);Mountain(r,x+30,505,430,245,t);Mountain(r,x+440,505,520,300,t);Mountain(r,x+930,505,390,220,t);}float hs=fmodf(cam*.34f,900);for(int i=-1;i<4;++i){int x=(int)(i*900-hs);Ellipse(r,x+220,535,300,115,hill);Ellipse(r,x+650,545,330,100,{(Uint8)max(0,(int)hill.r-15),(Uint8)max(0,(int)hill.g-15),(Uint8)max(0,(int)hill.b-15),255});}float ts=fmodf(cam*.52f,360);for(int i=-1;i<7;++i){int x=(int)(i*360-ts);Tree(r,x+90,575,.67f,t);Tree(r,x+260,580,.56f,t);}}
void Ground(SDL_Renderer*r,float cam,float gy,Theme t){Color dirt={135,83,51,255},dark={104,61,43,255},grass={83,159,65,255},light={145,196,78,255};if(t==Theme::AUTUMN){dirt={145,91,55,255};grass={168,105,48,255};light={223,159,69,255};}if(t==Theme::MOONLIGHT){dirt={77,76,91,255};dark={52,54,72,255};grass={67,119,105,255};light={121,174,135,255};}if(t==Theme::MUSHROOM){dirt={107,91,101,255};grass={89,145,117,255};light={151,194,143,255};}Rect(r,0,(int)gy,SW,720-(int)gy,dirt);Rect(r,0,655,SW,65,dark);Rect(r,0,(int)gy,SW,22,grass);SetColor(r,light);SDL_RenderDrawLine(r,0,(int)gy,SW,(int)gy);for(int x=0;x<SW;x+=24){SDL_RenderDrawLine(r,x,(int)gy,x+4,(int)gy-7);SDL_RenderDrawLine(r,x+5,(int)gy,x+10,(int)gy-5);}float shift=fmodf(cam,170);for(int i=-1;i<10;++i){int x=(int)(i*170-shift);Ellipse(r,x+45,620,25,12,{151,96,62,255});Ellipse(r,x+115,680,32,14,{82,51,39,255});}}
void DrawPlatform(SDL_Renderer*r,const Platform&p,float cam){int x=(int)(p.x-cam);if(x+(int)p.w<-20||x>SW+20)return;Rect(r,x,(int)p.y,(int)p.w,(int)p.h,{135,83,51,255});Rect(r,x,(int)(p.y+p.h-9),(int)p.w,9,{104,61,43,255});Rect(r,x-3,(int)p.y-8,(int)p.w+6,12,{83,159,65,255});SetColor(r,{145,196,78,255});SDL_RenderDrawLine(r,x-2,(int)p.y-8,x+(int)p.w+2,(int)p.y-8);}

// ---------------- FOX / OBJECT ART ----------------
void FoxDraw(SDL_Renderer*r,const Fox&f,float cam,float gy){float x=f.x-cam,y=f.footY;int step=f.onGround?(int)(sinf(f.animTime)*5):0;Ellipse(r,(int)(x+85),(int)gy+2,f.onGround?58:34,8,{45,78,43,105});auto ex=[&](int lx,int ly,int rx,int ry,Color c){int xx=f.facingRight?lx:190-lx;Ellipse(r,(int)x+xx,(int)y+ly,rx,ry,c);};ex(26,-70,53,34,{65,38,28,255});ex(30,-74,51,31,{235,112,35,255});ex(8,-85,25,23,{255,235,202,255});ex(40,-91,23,10,{255,157,65,255});ex(91,-51,68,39,{65,38,28,255});ex(93,-55,65,37,{235,112,35,255});ex(125,-41,30,26,{255,235,202,255});ex(54,-18+step,15,24,{65,38,28,255});ex(55,-11+step,17,9,{65,38,28,255});ex(103,-18-step,14,23,{65,38,28,255});ex(106,-10-step,17,9,{65,38,28,255});ex(133,-20-step,12,24,{235,112,35,255});ex(136,-7-step,17,8,{65,38,28,255});ex(151,-18+step,11,22,{235,112,35,255});ex(154,-6+step,16,8,{65,38,28,255});ex(142,-100,42,39,{65,38,28,255});ex(142,-103,40,38,{235,112,35,255});auto tri=[&](SDL_Point a,SDL_Point b,SDL_Point c,Color col){if(!f.facingRight){a.x=190-a.x;b.x=190-b.x;c.x=190-c.x;}Triangle(r,{(int)x+a.x,(int)y+a.y},{(int)x+b.x,(int)y+b.y},{(int)x+c.x,(int)y+c.y},col);};tri({108,-124},{115,-170},{137,-132},{65,38,28,255});tri({111,-127},{117,-164},{134,-134},{235,112,35,255});tri({145,-132},{166,-166},{174,-123},{65,38,28,255});tri({150,-132},{165,-158},{170,-127},{235,112,35,255});ex(164,-83,27,17,{255,235,202,255});ex(153,-109,9,11,{65,38,28,255});ex(154,-111,7,9,{255,255,255,255});ex(156,-111,4,6,{65,38,28,255});ex(181,-85,7,5,{30,25,25,255});}
void BerryDraw(SDL_Renderer*r,const Berry&b,float cam,float time){int x=(int)(b.x-cam),y=(int)b.y;if(x<-40||x>SW+40)return;int glow=20+(int)(2*sinf(time*3));Ellipse(r,x,y,glow,glow,{255,205,90,55});Ellipse(r,x,y+16,15,5,{54,83,43,90});Ellipse(r,x-5,y,11,14,{175,31,55,255});Ellipse(r,x+5,y,11,14,{224,48,70,255});Ellipse(r,x,y+6,10,9,{203,36,59,255});Ellipse(r,x-5,y-5,3,4,{255,151,151,255});Triangle(r,{x,y-13},{x-12,y-20},{x-3,y-8},{73,166,76,255});Triangle(r,{x+1,y-13},{x+12,y-20},{x+4,y-8},{91,184,81,255});}
void DenDraw(SDL_Renderer*r,float cam,const LevelData&l){int x=(int)(l.denX-cam);if(x<-250||x>SW+250)return;Ellipse(r,x+108,(int)l.groundY+3,128,68,{72,137,66,255});Ellipse(r,x+57,(int)l.groundY-27,39,38,{126,112,91,255});Ellipse(r,x+158,(int)l.groundY-28,42,39,{126,112,91,255});Ellipse(r,x+108,(int)l.groundY-43,76,57,{105,86,65,255});Ellipse(r,x+108,(int)l.groundY-27,49,38,{42,34,29,255});Ellipse(r,x+108,(int)l.groundY-19,36,29,{17,20,19,255});}
void DrawHazard(SDL_Renderer*r,const Hazard&h,float cam,float time){
    int x=(int)(h.x-cam),y=(int)h.y,w=(int)h.w,hh=(int)h.h;
    if(x+w<-20||x>SW+20)return;
    int pulse=2+(int)(2.0f*(0.5f+0.5f*sinf(time*4.0f)));
    Ellipse(r,x+w/2,y+hh+3,w/2+8,5,{35,42,31,100});
    switch(h.type){
        case TrapType::THORNS:
            Rect(r,x,y+hh-9,w,9,{58,86,48,255});
            for(int i=0;i<4;++i)Triangle(r,{x+8+i*(w-16)/3,y+hh-7},{x+22+i*(w-16)/3,y+hh-7},{x+15+i*(w-16)/3,y+3},{62,126,63,255});
            break;
        case TrapType::CANOPY_VINE:
            Rect(r,x,y+hh-8,w,8,{54,111,65,255});
            for(int i=0;i<4;++i){int bx=x+12+i*(w-24)/3;Triangle(r,{bx,y+hh-5},{bx+20,y+hh-5},{bx+11,y+5},{75,145,75,255});}
            break;
        case TrapType::SPORE:
            Ellipse(r,x+w/2,y+hh/2,w/2+4,hh/2+3,{123,69,139,100});
            for(int i=0;i<5;++i){int sx=x+10+i*(w-20)/4;int sy=y+8+(i%2)*7;Ellipse(r,sx,sy,7+pulse,7+pulse,{195,111,211,220});Ellipse(r,sx-2,sy-2,2,2,{255,225,255,255});}
            break;
        case TrapType::HOT_LEAVES:
            Rect(r,x,y+hh-7,w,7,{125,63,34,255});
            for(int i=0;i<5;++i){int lx=x+8+i*(w-16)/4;Triangle(r,{lx,y+hh-5},{lx+20,y+hh-5},{lx+12,y+4+(i%2)*5},{222,102,39,255});}
            break;
        case TrapType::MOON_CRYSTAL:
            Rect(r,x,y+hh-7,w,7,{57,91,105,255});
            for(int i=0;i<4;++i){int cx=x+10+i*(w-20)/3;Triangle(r,{cx-8,y+hh-5},{cx+8,y+hh-5},{cx,y+2},{106,220,235,255});}
            Ellipse(r,x+w/2,y+hh/2,w/2+8,hh/2+6,{88,210,235,25});
            break;
    }
}

void DrawHealthHUD(SDL_Renderer*r,int health,float time,float damageFlash){
    Rect(r,620,22,190,86,{31,62,46,225});
    Outline(r,620,22,190,86,{255,224,166,255});
    Text(r,"HEALTH",642,34,2,{255,245,220,255});
    const bool critical=health==1;
    float pulse=critical?(0.5f+0.5f*sinf(time*8.5f)):0.0f;
    for(int i=0;i<3;++i){
        int x=665+i*52,y=76;
        bool full=i<health;
        int extra=(full&&critical)?(int)(3.0f*pulse):0;
        Color c=full?Color{225,65,77,255}:Color{86,75,72,255};
        if(full&&damageFlash>0.0f)c={255,130,132,255};
        Ellipse(r,x-7,y-4,9+extra,9+extra,c);
        Ellipse(r,x+7,y-4,9+extra,9+extra,c);
        Triangle(r,{x-16-extra,y-2-extra},{x+16+extra,y-2-extra},{x,y+17+extra},c);
        if(full){
            Ellipse(r,x-9,y-7,2,2,{255,205,202,220});
        }
    }
    if(health==0)Text(r,"EMPTY",744,78,1,{255,170,145,255});
    else if(critical)Text(r,"LOW!",744,78,1,{255,190,135,255});
}

void DrawHUD(SDL_Renderer*r,int n,int score){Rect(r,24,22,320,86,{31,62,46,220});Outline(r,24,22,320,86,{255,224,166,255});Text(r,"BERRIES",44,34,2,{255,245,220,255});Text(r,to_string(n)+"/5",44,67,3,{255,225,151,255});Rect(r,365,22,230,86,{31,62,46,220});Outline(r,365,22,230,86,{255,224,166,255});Text(r,"SCORE",386,34,2,{255,245,220,255});Text(r,to_string(score),386,67,3,{255,225,151,255});}
void DrawControls(SDL_Renderer*r){auto circle=[&](int x,int y,bool jump){Ellipse(r,x,y,53,53,{22,48,42,115});SetColor(r,{245,255,235,230});for(int d=0;d<360;d+=4){float a=d*3.14159265f/180;SDL_RenderDrawPoint(r,x+(int)(51*cosf(a)),y+(int)(51*sinf(a)));}if(jump){SDL_RenderDrawLine(r,x,y+20,x,y-20);SDL_RenderDrawLine(r,x,y-20,x-16,y-2);SDL_RenderDrawLine(r,x,y-20,x+16,y-2);}else{int dir=x<180?-1:1,end=x+dir*19;SDL_RenderDrawLine(r,x-dir*19,y,end,y);SDL_RenderDrawLine(r,end,y,end-dir*14,y-14);SDL_RenderDrawLine(r,end,y,end-dir*14,y+14);}};circle(112,632,false);circle(272,632,false);circle(1160,632,true);}

// ---------------- LEVEL SELECT SCREEN ----------------
struct Node { int x,y; };
const array<Node,5> NODES={Node{165,365},Node{400,245},Node{650,365},Node{900,245},Node{1115,365}};
void ThickLine(SDL_Renderer*r,int x1,int y1,int x2,int y2,int width,Color c){SetColor(r,c);float dx=(float)(x2-x1),dy=(float)(y2-y1);float len=sqrtf(dx*dx+dy*dy);if(len<1)return;for(int off=-width/2;off<=width/2;++off){int ox=(int)(-dy/len*off),oy=(int)(dx/len*off);SDL_RenderDrawLine(r,x1+ox,y1+oy,x2+ox,y2+oy);}}
void DrawStar(SDL_Renderer*r,int cx,int cy,int radius,Color c){SDL_Point p[10];for(int i=0;i<10;++i){float a=-1.5707963f+i*3.14159265f/5.0f;int rr=(i%2==0)?radius:radius/2;p[i]={cx+(int)(cosf(a)*rr),cy+(int)(sinf(a)*rr)};}for(int i=1;i<9;++i)Triangle(r,p[0],p[i],p[i+1],c);}
void DrawLock(SDL_Renderer*r,int cx,int cy){SetColor(r,{216,218,207,255});SDL_Rect sh{cx-11,cy-20,22,25};SDL_RenderDrawRect(r,&sh);Rect(r,cx-18,cy-5,36,30,{200,169,91,255});Outline(r,cx-18,cy-5,36,30,{77,65,43,255});Ellipse(r,cx,cy+5,4,5,{75,60,39,255});Rect(r,cx-2,cy+8,4,9,{75,60,39,255});}

void DrawLevelSelect(SDL_Renderer*r,const LevelManager&,const ProgressData&p,
                     int messageTimer,int focusLevel,float elapsed){
    Background(r,0,Theme::GREEN_FOREST);
    Ground(r,0,560,Theme::GREEN_FOREST);
    Rect(r,110,14,1060,132,{17,42,31,170});
    Outline(r,110,14,1060,132,{151,184,120,220});
    CenterText(r,"WORLD MAP",640,28,5,{255,239,194,255});
    CenterText(r,"TAP A WORLD TO PLAY OR REPLAY  -  PC: PRESS 1-5",640,83,2,{242,247,220,255});
    CenterText(r,"3 STARS: 45 SEC OR LESS  |  2 STARS: 75 SEC OR LESS",640,119,2,{255,225,151,255});

    // Winding trail: dark edge, warm path, and a subtle grass center highlight.
    for(int i=0;i<4;++i){
        Node a=NODES[i],b=NODES[i+1];
        ThickLine(r,a.x,a.y+3,b.x,b.y+3,31,{42,57,39,255});
        ThickLine(r,a.x,a.y,b.x,b.y,25,{104,79,53,255});
        ThickLine(r,a.x,a.y-2,b.x,b.y-2,15,{220,190,128,255});
        ThickLine(r,a.x,a.y-3,b.x,b.y-3,3,{245,220,160,160});
    }

    const char* shortNames[5]={"GREEN","CANOPY","MUSHROOM","AUTUMN","MOONLIGHT"};

    for(int i=0;i<LEVEL_COUNT;++i){
        Node n=NODES[i];
        bool unlocked=p.IsUnlocked(i);
        bool done=p.completed[i];
        bool focused=(focusLevel>0 && i==focusLevel && unlocked && !done);

        if(focused){
            int pulse=5+(int)(3.0f*(0.5f+0.5f*sinf(elapsed*4.0f)));
            Ellipse(r,n.x,n.y-4,54+pulse,54+pulse,
                    {255,224,130,100});
        }

        Ellipse(r,n.x,n.y+13,61,20,{28,57,43,130});
        Ellipse(r,n.x,n.y,56,56,{31,49,37,255});
        Ellipse(r,n.x,n.y,51,51,{170,143,95,255});
        Ellipse(r,n.x,n.y-4,45,45,!unlocked?Color{111,117,111,255}:done?Color{74,143,80,255}:Color{231,142,49,255});
        Ellipse(r,n.x,n.y-6,37,37,!unlocked?Color{86,96,88,255}:done?Color{104,175,93,255}:Color{250,177,69,255});

        if(unlocked){
            CenterText(r,to_string(i+1),n.x,n.y-20,5,{255,250,221,255});
            if(done){
                for(int st=0;st<3;++st)DrawStar(r,n.x-25+st*25,n.y+57,9,st<p.bestStars[i]?Color{255,216,93,255}:Color{88,99,82,255});
            }else CenterText(r,"GO",n.x,n.y+21,1,{255,250,221,255});
        }else DrawLock(r,n.x,n.y-1);

        CenterText(r,shortNames[i],n.x,n.y+78,2,unlocked?Color{255,245,220,255}:Color{190,194,181,255});
        if(focused) CenterText(r,"NEW",n.x,n.y-75,2,{255,233,153,255});

        if(done){
            CenterText(r,"CLEARED",n.x,n.y+98,1,{190,235,175,255});
            if(p.bestScore[i]>0)
                CenterText(r,"BEST "+to_string(p.bestScore[i]),n.x,n.y+111,1,{255,224,145,255});
            CenterText(r,"REPLAY",n.x,n.y+126,2,{255,232,163,255});
        }else if(!unlocked){
            CenterText(r,"LOCKED",n.x,n.y+99,1,{210,210,197,255});
        }else{
            CenterText(r,"AVAILABLE",n.x,n.y+99,1,{255,224,145,255});
        }
    }

    Rect(r,20,640,1240,55,{35,72,51,225});
    Outline(r,20,640,1240,55,{255,222,151,255});
    Text(r,"UNLOCKED",45,659,2,{255,239,194,255});
    Text(r,to_string(p.highestUnlocked+1)+"/5",180,659,2,{255,225,151,255});
    int completedCount=0;
    for(bool done:p.completed) if(done) ++completedCount;
    Text(r,"COMPLETED",300,659,2,{255,239,194,255});
    Text(r,to_string(completedCount)+"/5",475,659,2,{255,225,151,255});
    int starTotal=0;for(int value:p.bestStars)starTotal+=value;
    Text(r,"STARS",590,659,2,{255,239,194,255});
    Text(r,to_string(starTotal)+"/15",690,659,2,{255,225,151,255});
    Button(r,{1080,650,145,42},"BACK");

    if(messageTimer>0)
        CenterText(r,"LOCKED - COMPLETE PREVIOUS LEVEL",640,605,2,{255,225,151,255});
}

// Mission 23: a runtime checkpoint snapshot. This is intentionally separate
// from permanent progression saves: checkpoints only affect the active run.
struct CheckpointSnapshot {
    float x=180.0f,footY=560.0f,camera=0.0f;
    int collected=0,score=0;
    vector<bool> berryCollected;
    bool reached=false;
};

void DrawCheckpoint(SDL_Renderer*r,float worldX,float camera,float groundY,bool reached,float elapsed){
    int x=(int)lroundf(worldX-camera),base=(int)groundY;
    if(x<-35||x>SW+35)return;
    // Wooden post and a bright flag make the checkpoint readable at a glance.
    Rect(r,x-4,base-112,8,112,{112,76,48,255});
    Rect(r,x-7,base-116,14,8,{226,192,126,255});
    Color flag=reached?Color{100,220,126,255}:Color{255,202,91,255};
    Triangle(r,{x+3,base-108},{x+62,base-91+(int)(sinf(elapsed*3.0f)*3.0f)},{x+3,base-73},flag);
    Ellipse(r,x,base-115,7,7,{255,239,180,255});
    if(reached){
        Ellipse(r,x,base-133,16,16,{112,235,145,65});
        Text(r,"CHECKPOINT",x-47,base-151,1,{194,255,205,255});
    }else Text(r,"CHECKPOINT",x-47,base-139,1,{255,231,174,255});
}

// ---------------- GAME OBJECT ----------------
struct Game {
    Scene scene=Scene::MENU;
    LevelManager levels;
    ProgressData progress;
    Fox fox;
    float camera=0,elapsed=0,levelTime=0;
    int collected=0,score=0,selectedLevel=0,messageTimer=0;
    int focusLevel=0;
    int earnedStars=0;
    Scene transitionFrom=Scene::MENU;
    Scene transitionTarget=Scene::MENU;
    float transitionTime=0.0f;
    bool transitionSwitched=false;
    bool saveWarning=false;
    bool replayMode=false;
    int pendingLevel=-1;
    bool jumpWasDown=false,mouseDown=false,ml=false,mr=false,mj=false;
    bool controlsBlockedUntilRelease=false;
    float coyoteTime=0.0f,jumpBufferTime=0.0f;
    int health=3;
    float invulnerabilityTime=0.0f,damageFlashTime=0.0f;
    float deathTimer=0.0f;
    CheckpointSnapshot checkpoint;
    float checkpointNoticeTime=0.0f;
    unordered_map<Sint64,int> fingers;
    vector<Berry> berries;
    vector<Particle> particles;

    Game(){progress.Load();LoadLevel(0);focusLevel=progress.highestUnlocked;}

    // Clear transient inputs whenever gameplay is interrupted or resumed.
    // The player must release held controls before they can move again.
    void ReleaseGameplayInput(){
        fingers.clear();
        mouseDown=ml=mr=mj=false;
        jumpWasDown=false;
        coyoteTime=0.0f;
        jumpBufferTime=0.0f;
        controlsBlockedUntilRelease=true;
    }

    // Start a short fade-out / fade-in transition.
    void BeginTransition(Scene target,int level=-1){
        if(scene==Scene::TRANSITION)return;
        if(scene==Scene::PLAYING || target==Scene::PLAYING) ReleaseGameplayInput();
        transitionFrom=scene;
        transitionTarget=target;
        transitionTime=0.0f;
        transitionSwitched=false;
        pendingLevel=level;
        scene=Scene::TRANSITION;
    }

    void UpdateTransition(float dt){
        if(scene!=Scene::TRANSITION)return;
        transitionTime+=dt;
        if(!transitionSwitched&&transitionTime>=0.22f){
            transitionSwitched=true;
            if(transitionTarget==Scene::PLAYING&&pendingLevel>=0)
                LoadLevel(pendingLevel);
        }
        if(transitionTime>=0.44f){
            scene=transitionTarget;
            transitionTime=0.0f;
            transitionSwitched=false;
            pendingLevel=-1;
        }
    }

    int TransitionAlpha()const{
        if(scene!=Scene::TRANSITION)return 0;
        if(!transitionSwitched)
            return (int)min(255.0f,transitionTime/0.22f*255.0f);
        return (int)max(0.0f,(1.0f-(transitionTime-0.22f)/0.22f)*255.0f);
    }

    void LoadLevel(int index){
        if(!levels.Load(index))return;
        selectedLevel=index;
        const LevelData& l=levels.Current();
        fox=Fox();fox.footY=l.groundY;
        camera=0;elapsed=0;levelTime=0;collected=0;score=0;earnedStars=0;
        coyoteTime=0.0f;jumpBufferTime=0.0f;
        health=3;invulnerabilityTime=0.0f;damageFlashTime=0.0f;
        berries.clear();for(auto b:l.berryPositions)berries.push_back({b.first,b.second,false});
        checkpoint=CheckpointSnapshot();
        checkpoint.x=fox.x;checkpoint.footY=fox.footY;checkpoint.camera=0.0f;
        checkpoint.berryCollected.assign(berries.size(),false);
        checkpoint.reached=false;
        checkpointNoticeTime=0.0f;
        particles.clear();
        ReleaseGameplayInput();
        deathTimer=0.0f;
    }

    // Mission 23: restore the most recent checkpoint snapshot. The run timer
    // keeps advancing and receives the same eight-second death penalty.
    void RespawnAtCheckpoint(AudioSystem& audio){
        const float penalizedTime=levelTime+8.0f;
        fox=Fox();
        fox.x=checkpoint.x;
        fox.footY=checkpoint.footY;
        fox.onGround=true;
        fox.vy=0.0f;
        camera=checkpoint.camera;
        collected=checkpoint.collected;
        score=checkpoint.score;
        for(size_t i=0;i<berries.size();++i)
            berries[i].collected=(i<checkpoint.berryCollected.size())?checkpoint.berryCollected[i]:false;
        particles.clear();
        health=3;
        invulnerabilityTime=1.20f;
        damageFlashTime=0.0f;
        checkpointNoticeTime=0.0f;
        levelTime=penalizedTime;
        coyoteTime=0.0f;
        jumpBufferTime=0.0f;
        deathTimer=0.0f;
        ReleaseGameplayInput();
        scene=Scene::PLAYING;
        audio.Respawn();
    }

    void CaptureCheckpoint(){
        const LevelData& l=levels.Current();
        checkpoint.x=l.checkpointX;
        checkpoint.footY=l.groundY;
        checkpoint.camera=max(0.0f,min(l.worldWidth-SW,checkpoint.x-430.0f));
        checkpoint.collected=collected;
        checkpoint.score=score;
        checkpoint.berryCollected.clear();
        for(const Berry& b:berries)checkpoint.berryCollected.push_back(b.collected);
        checkpoint.reached=true;
        checkpointNoticeTime=2.2f;
        // A short rising chime confirms that the snapshot is now safe.
    }

    void StartLevel(int index,AudioSystem&a){
        if(!progress.IsUnlocked(index)){
            messageTimer=150;
            return;
        }
        focusLevel=index;
        // Replaying a cleared level never resets or removes saved completion.
        replayMode=progress.completed[index];
        BeginTransition(Scene::PLAYING,index);
        a.Click();
    }

    // Convert real window coordinates into the fixed 1280x720 game canvas.
    // SDL 2.0.18+ accounts for the renderer viewport and letterbox bars.
    // Older SDL2 versions use the equivalent uniform-scale calculation.
    bool Logical(SDL_Window*w,SDL_Renderer*r,float px,float py,float&x,float&y){
#if SDL_VERSION_ATLEAST(2,0,18)
        (void)w;
        SDL_RenderWindowToLogical(r,(int)lroundf(px),(int)lroundf(py),&x,&y);
#else
        int ww=0,wh=0;SDL_GetWindowSize(w,&ww,&wh);if(ww<=0||wh<=0)return false;
        float scale=min(ww/(float)SW,wh/(float)SH);
        float ox=(ww-SW*scale)*0.5f,oy=(wh-SH*scale)*0.5f;
        x=(px-ox)/scale;y=(py-oy)/scale;
#endif
        // Reject taps in the letterbox bars instead of mapping them to buttons.
        return x>=0.0f&&x<(float)SW&&y>=0.0f&&y<(float)SH;
    }

    void TouchAt(float x,float y,int&c){
        c=0;
        // Broad, separated touch zones remain easy to hit on phone screens,
        // while matching the three visible controls at the bottom of the HUD.
        if(y<550||y>715)return;
        if(x>=35&&x<185)c=1;
        else if(x>=195&&x<350)c=2;
        else if(x>=1070&&x<1255)c=3;
    }

    void Tap(float x,float y,AudioSystem&a){
        int px=(int)x,py=(int)y;
        if(scene==Scene::MENU){
            // The sound toggle is visible on this screen and must be interactive.
            if(Inside(px,py,{1065,26,92,66})){a.ToggleMute();a.Click();}
            else if(Inside(px,py,{500,350,280,74})){BeginTransition(Scene::LEVEL_SELECT);a.Click();}
            else if(Inside(px,py,{500,430,280,58})){BeginTransition(Scene::HOW_TO);a.Click();}
            else if(Inside(px,py,{500,505,280,58})){BeginTransition(Scene::SETTINGS);a.Click();}
        }
        else if(scene==Scene::HOW_TO){
            if(Inside(px,py,{1065,26,92,66})){a.ToggleMute();a.Click();}
            else if(Inside(px,py,{500,545,280,62})){BeginTransition(Scene::MENU);a.Click();}
        }
        else if(scene==Scene::SETTINGS){
            // Hitboxes now match the exact rectangles drawn by DrawSettings().
            if(Inside(px,py,{410,300,54,45}))a.SetMusicVolume(a.MusicVolume()-5);
            else if(Inside(px,py,{410,395,54,45}))a.SetSfxVolume(a.SfxVolume()-5);
            else if(Inside(px,py,{885,300,54,45}))a.SetMusicVolume(a.MusicVolume()+5);
            else if(Inside(px,py,{885,395,54,45}))a.SetSfxVolume(a.SfxVolume()+5);
            else if(Inside(px,py,{500,465,280,52}))a.ToggleMute();
            else if(Inside(px,py,{500,525,280,48}))a.ResetAudio();
            else if(Inside(px,py,{500,580,280,48})){BeginTransition(Scene::MENU);a.Click();}
        }
        else if(scene==Scene::LEVEL_SELECT){
            if(Inside(px,py,{1080,650,145,42})){BeginTransition(Scene::MENU);a.Click();return;}
            for(int i=0;i<LEVEL_COUNT;++i){Node n=NODES[i];int dx=px-n.x,dy=py-n.y;if(dx*dx+dy*dy<=58*58){if(progress.IsUnlocked(i))StartLevel(i,a);else messageTimer=150;return;}}
        }
        else if(scene==Scene::PLAYING){
            if(Inside(px,py,{1065,26,92,66})){a.ToggleMute();a.Click();}
            else if(Inside(px,py,{1170,26,84,66})){ReleaseGameplayInput();scene=Scene::PAUSED;a.Click();}
        }
        else if(scene==Scene::PAUSED){
            if(Inside(px,py,{500,310,280,62})){scene=Scene::PLAYING;a.Click();}
            else if(Inside(px,py,{500,390,280,62})){StartLevel(selectedLevel,a);}
            else if(Inside(px,py,{500,470,280,62})){BeginTransition(Scene::LEVEL_SELECT);a.Click();}
        }
        else if(scene==Scene::LEVEL_COMPLETE){
            if(Inside(px,py,{500,485,280,58})){BeginTransition(Scene::LEVEL_SELECT);a.Click();}
            else if(Inside(px,py,{500,550,280,42})){StartLevel(selectedLevel,a);}
        }
        else if(scene==Scene::GAME_COMPLETE){
            if(Inside(px,py,{500,515,280,48})){BeginTransition(Scene::LEVEL_SELECT);a.Click();}
            else if(Inside(px,py,{500,570,280,42})){BeginTransition(Scene::MENU);a.Click();}
        }
    }

    void Event(SDL_Window*w,SDL_Renderer*r,const SDL_Event&e,AudioSystem&a){
        // Android can suspend or hide the app without delivering normal finger-up
        // events. Pause safely and discard every transient input on interruption.
        bool interrupted=(e.type==SDL_APP_WILLENTERBACKGROUND) ||
            (e.type==SDL_WINDOWEVENT &&
             (e.window.event==SDL_WINDOWEVENT_FOCUS_LOST ||
              e.window.event==SDL_WINDOWEVENT_HIDDEN ||
              e.window.event==SDL_WINDOWEVENT_MINIMIZED));
        if(interrupted){
            ReleaseGameplayInput();
            if(scene==Scene::PLAYING) scene=Scene::PAUSED;
            else if(scene==Scene::TRANSITION && transitionFrom==Scene::PAUSED && transitionTarget==Scene::PLAYING){
                scene=Scene::PAUSED;transitionTime=0.0f;transitionSwitched=false;pendingLevel=-1;
            }
            return;
        }
        if(e.type==SDL_KEYDOWN&&!e.key.repeat){SDL_Keycode k=e.key.keysym.sym;
            if(k==SDLK_ESCAPE){
                if(scene==Scene::PLAYING)BeginTransition(Scene::PAUSED);
                else if(scene==Scene::PAUSED)BeginTransition(Scene::PLAYING);
                else if(scene==Scene::HOW_TO||scene==Scene::LEVEL_SELECT||scene==Scene::SETTINGS)BeginTransition(Scene::MENU);
                a.Click();
            }
            if(k==SDLK_m&&scene!=Scene::SETTINGS){a.ToggleMute();a.Click();}
            if(scene==Scene::MENU&&(k==SDLK_RETURN||k==SDLK_SPACE)){BeginTransition(Scene::LEVEL_SELECT);a.Click();}
            else if(scene==Scene::HOW_TO&&(k==SDLK_RETURN||k==SDLK_SPACE)){BeginTransition(Scene::MENU);a.Click();}
            else if(scene==Scene::SETTINGS){
                if(k==SDLK_LEFT)a.SetMusicVolume(a.MusicVolume()-5);
                if(k==SDLK_RIGHT)a.SetMusicVolume(a.MusicVolume()+5);
                if(k==SDLK_DOWN)a.SetSfxVolume(a.SfxVolume()-5);
                if(k==SDLK_UP)a.SetSfxVolume(a.SfxVolume()+5);
                if(k==SDLK_m)a.ToggleMute();
                if(k==SDLK_r)a.ResetAudio();
                if(k==SDLK_RETURN||k==SDLK_SPACE||k==SDLK_b)BeginTransition(Scene::MENU);
            }
            else if(scene==Scene::LEVEL_SELECT&&k>=SDLK_1&&k<=SDLK_5){
                int requested=(int)(k-SDLK_1);
                if(progress.IsUnlocked(requested))StartLevel(requested,a);
                else messageTimer=150;
            }
            else if(scene==Scene::PAUSED){
                if(k==SDLK_RETURN||k==SDLK_SPACE){BeginTransition(Scene::PLAYING);a.Click();}
                if(k==SDLK_r)StartLevel(selectedLevel,a);
                if(k==SDLK_b){BeginTransition(Scene::LEVEL_SELECT);a.Click();}
            }
            else if(scene==Scene::LEVEL_COMPLETE){
                if(k==SDLK_RETURN||k==SDLK_SPACE||k==SDLK_b){BeginTransition(Scene::LEVEL_SELECT);a.Click();}
                if(k==SDLK_r)StartLevel(selectedLevel,a);
            }
            else if(scene==Scene::GAME_COMPLETE){
                if(k==SDLK_RETURN||k==SDLK_SPACE){BeginTransition(Scene::LEVEL_SELECT);a.Click();}
                if(k==SDLK_b){BeginTransition(Scene::MENU);a.Click();}
            }
        }
        if(e.type==SDL_MOUSEBUTTONDOWN&&e.button.button==SDL_BUTTON_LEFT){float x=0,y=0;if(Logical(w,r,e.button.x,e.button.y,x,y)){Tap(x,y,a);if(scene==Scene::PLAYING){int c=0;TouchAt(x,y,c);ml=c==1;mr=c==2;mj=c==3;mouseDown=true;}}}
        if(e.type==SDL_MOUSEBUTTONUP&&e.button.button==SDL_BUTTON_LEFT){mouseDown=false;ml=mr=mj=false;}
        if(e.type==SDL_MOUSEMOTION&&mouseDown&&scene==Scene::PLAYING){
            float x=0,y=0;
            if(Logical(w,r,e.motion.x,e.motion.y,x,y)){int c=0;TouchAt(x,y,c);ml=c==1;mr=c==2;mj=c==3;}
            else ml=mr=mj=false;
        }
        if(e.type==SDL_FINGERDOWN||e.type==SDL_FINGERMOTION||e.type==SDL_FINGERUP){
            int ww=0,wh=0;SDL_GetWindowSize(w,&ww,&wh);float x=0,y=0;
            if(e.type==SDL_FINGERUP)fingers.erase(e.tfinger.fingerId);
            else if(!Logical(w,r,e.tfinger.x*ww,e.tfinger.y*wh,x,y))fingers.erase(e.tfinger.fingerId);
            else {
                if(e.type==SDL_FINGERDOWN)Tap(x,y,a);
                if(scene==Scene::PLAYING){int c=0;TouchAt(x,y,c);if(c)fingers[e.tfinger.fingerId]=c;else fingers.erase(e.tfinger.fingerId);}
                else fingers.erase(e.tfinger.fingerId);
            }
        }
    }

    static bool Overlaps(float ax,float ay,float aw,float ah,float bx,float by,float bw,float bh){
        return ax<bx+bw && ax+aw>bx && ay<by+bh && ay+ah>by;
    }

    void ApplyTrapDamage(const Hazard& hazard,AudioSystem& audio){
        if(health<=0 || invulnerabilityTime>0.0f)return;
        --health;
        invulnerabilityTime=1.20f;
        damageFlashTime=0.24f;
        float hazardCenter=hazard.x+hazard.w*0.5f;
        fox.x += (fox.x+95.0f<hazardCenter)?-82.0f:82.0f;
        const LevelData& level=levels.Current();
        fox.x=max(0.0f,min(level.worldWidth-190.0f,fox.x));
        fox.vy=-300.0f;
        fox.onGround=false;
        audio.Damage();
        if(health==1)audio.CriticalHealth();
        if(health==0){
            deathTimer=0.0f;
            ReleaseGameplayInput();
            scene=Scene::PLAYER_DYING;
            audio.Death();
        }
    }

    void AddParticles(float x,float y){for(int i=0;i<12;++i){float a=i*6.2831853f/12,s=65+(i%3)*22;particles.push_back({x,y,cosf(a)*s,sinf(a)*s-25,.45f,.45f,i%2?Color{255,245,207,255}:Color{255,211,100,255}});}}

    void Update(float dt,AudioSystem&a){
        elapsed+=dt;
        if(messageTimer>0)--messageTimer;
        if(scene==Scene::TRANSITION){UpdateTransition(dt);return;}
        if(scene==Scene::PLAYER_DYING){
            deathTimer+=dt;
            fox.vy+=1050.0f*dt;
            fox.footY+=fox.vy*dt;
            fox.animTime+=dt*12.0f;
            if(deathTimer>=1.55f)RespawnAtCheckpoint(a);
            return;
        }
        if(scene!=Scene::PLAYING)return;
        invulnerabilityTime=max(0.0f,invulnerabilityTime-dt);
        damageFlashTime=max(0.0f,damageFlashTime-dt);
        checkpointNoticeTime=max(0.0f,checkpointNoticeTime-dt);
        levelTime+=dt;
        const LevelData& l=levels.Current();const Uint8*k=SDL_GetKeyboardState(nullptr);
        bool left=k[SDL_SCANCODE_LEFT]||k[SDL_SCANCODE_A]||ml;
        bool right=k[SDL_SCANCODE_RIGHT]||k[SDL_SCANCODE_D]||mr;
        bool jump=k[SDL_SCANCODE_SPACE]||k[SDL_SCANCODE_UP]||mj;
        for(auto f:fingers){if(f.second==1)left=true;if(f.second==2)right=true;if(f.second==3)jump=true;}
        // After a pause/focus-loss, ignore any control that is still held.
        // This prevents Android from continuing to run the fox when the app returns.
        if(controlsBlockedUntilRelease){
            if(!left&&!right&&!jump)controlsBlockedUntilRelease=false;
            else left=right=jump=false;
        }

        float oldX=fox.x;
        if(left&&!right){fox.x-=280*dt;fox.facingRight=false;}
        if(right&&!left){fox.x+=280*dt;fox.facingRight=true;}
        fox.x=max(0.0f,min(l.worldWidth-190.0f,fox.x));
        if(fabsf(fox.x-oldX)>.01f)fox.animTime+=dt*13;else fox.animTime+=dt*2.7f;

        if(fox.onGround&&fox.footY<l.groundY-1){
            bool support=false;
            for(const Platform&p:l.platforms){
                float top=p.y-8;bool same=fabsf(fox.footY-top)<2;
                bool overlap=fox.x+35<p.x+p.w&&fox.x+155>p.x;
                if(same&&overlap){support=true;break;}
            }
            if(!support){fox.onGround=false;fox.vy=0;}
        }

        // Small coyote-time and jump-buffer windows make keyboard and touch jumps
        // more forgiving without allowing repeated jumps while the button is held.
        if(fox.onGround)coyoteTime=0.12f;
        else coyoteTime=max(0.0f,coyoteTime-dt);
        bool jumpPressed=jump&&!jumpWasDown;
        if(jumpPressed)jumpBufferTime=0.14f;
        else jumpBufferTime=max(0.0f,jumpBufferTime-dt);
        jumpWasDown=jump;
        if(jumpBufferTime>0.0f&&coyoteTime>0.0f){
            fox.vy=-760;fox.onGround=false;a.Jump();
            jumpBufferTime=0.0f;coyoteTime=0.0f;
        }

        float oldY=fox.footY;
        if(!fox.onGround){
            fox.vy+=1500*dt;fox.footY+=fox.vy*dt;
            if(fox.vy>=0){
                // Select the highest crossed platform, not whichever platform
                // happens to appear first in the level's data array.
                float landingY=0.0f;
                if(FindLandingPlatformY(l.platforms,fox.x+35,fox.x+155,oldY,fox.footY,landingY)){
                    fox.footY=landingY;fox.vy=0;fox.onGround=true;
                }
            }
            if(!fox.onGround&&fox.footY>=l.groundY){fox.footY=l.groundY;fox.vy=0;fox.onGround=true;}
        }

        float cx=fox.x+95,cy=fox.footY-78;
        for(Berry&b:berries){if(b.collected)continue;float dx=cx-b.x,dy=cy-b.y;if(dx*dx/(58*58)+dy*dy/(88*88)<=1){b.collected=true;++collected;score+=100;AddParticles(b.x,b.y);a.Collect();}}

        // The checkpoint activates once the fox reaches its marker. Its saved
        // snapshot includes all berries collected up to this exact moment.
        if(!checkpoint.reached && fox.x+95.0f>=l.checkpointX){
            CaptureCheckpoint();
            a.Checkpoint();
        }

        // Traps only damage the fox when their world-space hitbox overlaps
        // the lower body. The 1.2s invulnerability window prevents rapid hits.
        if(health>0 && invulnerabilityTime<=0.0f){
            for(const Hazard& h:l.hazards){
                if(Overlaps(fox.x+48,fox.footY-126,108,118,h.x,h.y,h.w,h.h)){
                    ApplyTrapDamage(h,a);
                    break;
                }
            }
        }
        if(scene==Scene::PLAYER_DYING)return;
        for(Particle&p:particles){p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=220*dt;p.life-=dt;}
        particles.erase(remove_if(particles.begin(),particles.end(),[](const Particle&p){return p.life<=0;}),particles.end());

        if(collected==BERRY_COUNT&&fox.onGround&&fabsf(cx-(l.denX+108))<90){
            // All five berries are mandatory. Completion speed determines the
            // medal: <=45s earns 3, <=75s earns 2, otherwise 1.
            earnedStars=CalculateStarRating(levelTime);
            bool saved=progress.Complete(selectedLevel,score,earnedStars);
            saveWarning=!saved;
            if(!saved)cerr<<"WARNING: level completed, but progress could not be saved.\n";
            focusLevel=min(selectedLevel+1,LEVEL_COUNT-1);
            Scene target=(selectedLevel==LEVEL_COUNT-1)
                ? Scene::GAME_COMPLETE : Scene::LEVEL_COMPLETE;
            BeginTransition(target);
            a.Victory();
            return;
        }
        float target=max(0.0f,min(l.worldWidth-SW,fox.x-430));
        camera+=(target-camera)*min(1.0f,8*dt);
    }
};

// ---------------- SCREENS ----------------
void DrawMenu(SDL_Renderer*r,Game&g,bool muted){
    Background(r,0,Theme::GREEN_FOREST);
    Ground(r,0,560,Theme::GREEN_FOREST);

    // A compact title-card composition keeps the menu readable at 1280x720.
    Panel(r,285,90,710,560);
    Rect(r,310,108,660,7,{221,169,82,255});
    Rect(r,328,121,624,2,{122,170,101,255});
    CenterText(r,"HUNGRY LITTLE FOX",640,145,5,{255,237,190,255});
    CenterText(r,"A LITTLE FOREST ADVENTURE",640,202,2,{198,225,180,255});
    Rect(r,430,236,420,2,{116,155,97,255});
    Ellipse(r,418,237,5,5,{255,217,116,255});
    Ellipse(r,862,237,5,5,{255,217,116,255});

    int completedCount=0,starTotal=0;
    for(int i=0;i<LEVEL_COUNT;++i){
        if(g.progress.completed[i])++completedCount;
        starTotal+=g.progress.bestStars[i];
    }
    // Two stat cards make saved progress visible before entering the map.
    Rect(r,365,257,250,62,{20,43,31,210});
    Outline(r,365,257,250,62,{132,174,112,255});
    Text(r,"WORLDS CLEARED",385,270,1,{205,225,190,255});
    Text(r,to_string(completedCount)+" / 5",385,286,3,{255,235,184,255});
    Rect(r,665,257,250,62,{20,43,31,210});
    Outline(r,665,257,250,62,{132,174,112,255});
    Text(r,"BEST STARS",685,270,1,{205,225,190,255});
    Text(r,to_string(starTotal)+" / 15",685,286,3,{255,220,123,255});

    Text(r,"WORLD MAP PROGRESS",430,329,1,{225,235,211,255});
    Rect(r,430,346,420,12,{15,34,26,255});
    Outline(r,430,346,420,12,{185,193,151,255});
    int progressWidth=416*(g.progress.highestUnlocked+1)/LEVEL_COUNT;
    Rect(r,432,348,progressWidth,8,{135,194,105,255});

    Button(r,{500,350,280,74},"PLAY",true);
    Button(r,{500,430,280,58},"HOW TO PLAY");
    Button(r,{500,505,280,58},"SOUND SETTINGS");
    CenterText(r,"COLLECT BERRIES  -  FIND YOUR WAY HOME",640,590,1,{230,241,213,255});

    // The fox mascot decorates the card without covering any controls.
    Fox f;f.x=150;f.footY=560;FoxDraw(r,f,0,g.elapsed);
    Button(r,{1065,26,92,66},muted?"SND OFF":"SND ON");
}
void DrawAudioBar(SDL_Renderer*r,int x,int y,int value,const string&label){
    Text(r,label,x,y-27,2,{255,239,194,255});
    Rect(r,x,y,430,22,{20,38,29,255});
    Outline(r,x,y,430,22,{255,222,151,255});
    int fill=(int)(426*value/100.0f);
    if(fill>0)Rect(r,x+2,y+2,fill,18,{119,190,103,255});
    Text(r,to_string(value)+"%",x+445,y-2,2,{255,231,169,255});
}
void DrawSettings(SDL_Renderer*r,const AudioSystem&a){
    Background(r,0,Theme::GREEN_FOREST);Ground(r,0,560,Theme::GREEN_FOREST);
    Panel(r,300,105,680,535);
    CenterText(r,"SOUND SETTINGS",640,140,5,{255,232,180,255});
    DrawAudioBar(r,410,270,a.MusicVolume(),"MUSIC VOLUME");
    DrawAudioBar(r,410,365,a.SfxVolume(),"SOUND EFFECTS");
    Button(r,{410,300,54,45},"-");Button(r,{885,300,54,45},"+");
    Button(r,{410,395,54,45},"-");Button(r,{885,395,54,45},"+");
    Button(r,{500,465,280,52},a.IsMuted()?"UNMUTE ALL":"MUTE ALL");
    Button(r,{500,525,280,48},"RESET AUDIO");
    Button(r,{500,580,280,48},"BACK",true);
    CenterText(r,"LEFT/RIGHT: MUSIC   UP/DOWN: SFX   M: MUTE   R: RESET",640,220,1,{225,235,211,255});
}
void DrawHowTo(SDL_Renderer*r,bool muted){Background(r,0,Theme::GREEN_FOREST);Ground(r,0,560,Theme::GREEN_FOREST);Panel(r,280,115,720,500);CenterText(r,"HOW TO PLAY",640,155,5,{255,232,180,255});CenterText(r,"MOVE WITH A D OR ARROW KEYS",640,245,2,{245,244,223,255});CenterText(r,"JUMP WITH SPACE OR UP",640,292,2,{245,244,223,255});CenterText(r,"PHONE: USE THE TOUCH BUTTONS",640,339,2,{245,244,223,255});CenterText(r,"COLLECT ALL 5 BERRIES",640,399,3,{255,222,139,255});CenterText(r,"THEN REACH THE FOX DEN",640,443,3,{255,222,139,255});CenterText(r,"FINISH FAST TO EARN UP TO 3 STARS",640,490,2,{255,225,151,255});Button(r,{500,545,280,62},"BACK");Button(r,{1065,26,92,66},muted?"SND OFF":"SND ON");}
void DrawGameplay(SDL_Renderer*r,const Game&g,bool muted){
    const LevelData&l=g.levels.Current();
    Background(r,g.camera,l.theme);Ground(r,g.camera,l.groundY,l.theme);
    DrawCheckpoint(r,l.checkpointX,g.camera,l.groundY,g.checkpoint.reached,g.elapsed);
    for(const Platform&p:l.platforms)DrawPlatform(r,p,g.camera);
    for(const Hazard&h:l.hazards)DrawHazard(r,h,g.camera,g.elapsed);
    float shift=fmodf(g.camera*.82f,520);
    for(int i=-1;i<4;++i)Tree(r,(int)(i*520-shift)+420,560,.9f,l.theme);
    DenDraw(r,g.camera,l);
    for(const Berry&b:g.berries)if(!b.collected)BerryDraw(r,b,g.camera,g.elapsed);
    for(const Particle&p:g.particles){float a=max(0.0f,min(1.0f,p.life/p.maxLife));Color c=p.color;c.a=(Uint8)(a*255);Ellipse(r,(int)(p.x-g.camera),(int)p.y,4,4,c);}
    if(g.damageFlashTime>0.0f){
        Uint8 alpha=(Uint8)(55.0f*min(1.0f,g.damageFlashTime/0.24f));
        Rect(r,0,0,SW,SH,{220,35,45,alpha});
    }
    bool blink=g.invulnerabilityTime>0.0f && fmodf(g.elapsed*14.0f,2.0f)<1.0f;
    if(!blink)FoxDraw(r,g.fox,g.camera,l.groundY);
    DrawHUD(r,g.collected,g.score);DrawHealthHUD(r,g.health,g.elapsed,g.damageFlashTime);
    if(g.replayMode)CenterText(r,"REPLAY MODE",820,43,2,{255,225,151,255});
    if(g.checkpointNoticeTime>0.0f)CenterText(r,"CHECKPOINT ACTIVATED!",640,145,3,{188,255,190,255});
    Button(r,{1065,26,92,66},muted?"SND OFF":"SND ON");
    Rect(r,1170,26,84,66,{35,83,57,235});Outline(r,1170,26,84,66,{255,228,174,255});
    Rect(r,1197,44,9,30,{255,245,220,255});Rect(r,1218,44,9,30,{255,245,220,255});DrawControls(r);
}
void DrawDeath(SDL_Renderer*r,const Game&g,bool muted){
    DrawGameplay(r,g,muted);
    float fade=min(1.0f,g.deathTimer/0.22f);
    Uint8 shade=(Uint8)(105.0f+45.0f*fade);
    Rect(r,0,0,SW,SH,{16,13,20,shade});
    int panelY=218+(int)(sinf(g.deathTimer*5.0f)*3.0f);
    Panel(r,350,panelY,580,270);
    CenterText(r,"FOX DOWN",640,panelY+38,5,{255,190,165,255});
    CenterText(r,"YOU LOST ALL 3 HEARTS",640,panelY+105,2,{255,220,204,255});
    CenterText(r,"RETURNING TO CHECKPOINT",640,panelY+145,2,{255,235,210,255});
    // A clear countdown bar communicates the automatic respawn delay.
    Rect(r,445,panelY+190,390,15,{22,35,30,255});
    Outline(r,445,panelY+190,390,15,{255,224,166,255});
    float progress=max(0.0f,min(1.0f,g.deathTimer/1.55f));
    Rect(r,449,panelY+194,(int)(382.0f*progress),7,{255,190,112,255});
    int dots=((int)(g.deathTimer*5.0f))%4;
    string status="RESPAWNING";
    for(int i=0;i<dots;++i)status+=".";
    CenterText(r,status,640,panelY+224,1,{255,220,160,255});
}
void DrawPaused(SDL_Renderer*r,const Game&g,bool muted){DrawGameplay(r,g,muted);Panel(r,390,190,500,380);CenterText(r,"PAUSED",640,225,5,{255,232,180,255});Button(r,{500,310,280,62},"RESUME",true);Button(r,{500,390,280,62},"RESTART LEVEL");Button(r,{500,470,280,62},"LEVEL SELECT");}
void DrawComplete(SDL_Renderer*r,const Game&g,bool muted){
    DrawGameplay(r,g,muted);
    Panel(r,340,145,600,450);
    CenterText(r,"LEVEL COMPLETE",640,180,4,{255,232,180,255});
    CenterText(r,g.levels.Current().name,640,240,2,{216,240,199,255});
    for(int i=0;i<3;++i) DrawStar(r,590+i*50,305,20,i<g.earnedStars?Color{255,216,93,255}:Color{88,99,82,255});
    CenterText(r,(g.earnedStars==3?"GOLD PERFORMANCE":g.earnedStars==2?"GREAT PERFORMANCE":"LEVEL CLEARED"),640,330,1,{255,231,169,255});
    CenterText(r,"5 BERRIES COLLECTED",640,345,2,{255,224,153,255});
    CenterText(r,"FINAL SCORE",640,382,2,{245,244,223,255});
    CenterText(r,to_string(g.score),640,410,3,{255,232,180,255});
    if(g.saveWarning)
        CenterText(r,"SAVE FAILED - PROGRESS MAY NOT PERSIST",640,460,1,{255,170,130,255});
    else
        CenterText(r,"PROGRESS SAVED",640,460,1,{190,235,175,255});
    if(g.selectedLevel+1<LEVEL_COUNT)
        CenterText(r,"NEXT LEVEL UNLOCKED",640,435,2,{190,235,175,255});
    Button(r,{500,485,280,58},"CONTINUE",true);
    Button(r,{500,550,280,42},"REPLAY LEVEL");
}

void DrawGameComplete(SDL_Renderer*r,const Game&g){
    Background(r,0,Theme::MOONLIGHT);
    Ground(r,0,560,Theme::MOONLIGHT);
    Panel(r,300,115,680,500);
    CenterText(r,"ALL LEVELS COMPLETE",640,165,4,{255,232,180,255});
    CenterText(r,"THE FOX FOUND ITS WAY HOME",640,235,2,{216,240,199,255});
    for(int i=0;i<5;++i) DrawStar(r,490+i*75,325,25,{255,216,93,255});
    CenterText(r,"FIVE FORESTS CLEARED",640,390,3,{255,224,153,255});
    int starTotal=0;
    for(int value:g.progress.bestStars) starTotal+=value;
    CenterText(r,"TOTAL STARS  "+to_string(starTotal)+" / 15",640,418,2,{255,231,169,255});
    int total=0;
    for(int value:g.progress.bestScore) total+=value;
    CenterText(r,"BEST SCORE TOTAL",640,455,2,{245,244,223,255});
    CenterText(r,to_string(total),640,482,3,{255,232,180,255});
    CenterText(r,g.saveWarning?"SAVE FAILED - PROGRESS MAY NOT PERSIST":"PROGRESS SAVED",640,510,1,g.saveWarning?Color{255,170,130,255}:Color{190,235,175,255});
    Button(r,{500,515,280,48},"LEVEL MAP",true);
    Button(r,{500,570,280,42},"MAIN MENU");
}


void DrawTransitionOverlay(SDL_Renderer*r,int alpha){
    if(alpha<=0)return;
    Rect(r,0,0,SW,SH,{0,0,0,(Uint8)max(0,min(255,alpha))});
}

// Mission 20: preserve a 16:9 logical canvas on every display.
// SDL letterboxes wider/narrower outputs instead of stretching gameplay.
bool ConfigureLogicalViewport(SDL_Renderer*r){
    if(SDL_RenderSetLogicalSize(r,SW,SH)!=0)return false;
#if SDL_VERSION_ATLEAST(2,0,5)
    SDL_RenderSetIntegerScale(r,SDL_FALSE);
#endif
    SDL_SetRenderDrawBlendMode(r,SDL_BLENDMODE_BLEND);
    return true;
}

int main(){
    // Ask Android to keep the app in landscape. Android projects should also
    // set android:screenOrientation="landscape" in their manifest.
#ifdef SDL_HINT_ORIENTATIONS
    SDL_SetHint(SDL_HINT_ORIENTATIONS,"LandscapeLeft LandscapeRight");
#endif
    if(SDL_Init(SDL_INIT_VIDEO)<0){cout<<"SDL Video Error: "<<SDL_GetError()<<endl;return 1;}
    AudioSystem audio;if(!audio.Init())cout<<"Audio unavailable; running silently.\n";
    Uint32 windowFlags=SDL_WINDOW_SHOWN|SDL_WINDOW_RESIZABLE;
#if SDL_VERSION_ATLEAST(2,0,1)
    windowFlags|=SDL_WINDOW_ALLOW_HIGHDPI;
#endif
    SDL_Window*window=SDL_CreateWindow("HUNGRY LITTLE FOX - MISSION 24",SDL_WINDOWPOS_CENTERED,SDL_WINDOWPOS_CENTERED,SW,SH,windowFlags);
    if(!window){cout<<"Window Error: "<<SDL_GetError()<<endl;audio.Shutdown();SDL_Quit();return 1;}
    SDL_Renderer*r=SDL_CreateRenderer(window,-1,SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);if(!r)r=SDL_CreateRenderer(window,-1,SDL_RENDERER_SOFTWARE);
    if(!r){cout<<"Renderer Error: "<<SDL_GetError()<<endl;SDL_DestroyWindow(window);audio.Shutdown();SDL_Quit();return 1;}
    if(!ConfigureLogicalViewport(r))
        cout<<"Warning: logical viewport setup failed: "<<SDL_GetError()<<"\n";
    Game game;bool running=true;Uint32 prev=SDL_GetTicks();
    cout<<"MISSION 24 HEALTH HUD, DEATH UI AND AUDIO POLISH READY.\n";
    cout<<"Progress status: "<<game.progress.LoadStatusText()<<"\n";
    cout<<"Unlocked levels: "<<game.progress.highestUnlocked+1<<"/5\n";
    cout<<"Primary save: "<<PROGRESS_FILE<<"\n";
    cout<<"Backup save: "<<PROGRESS_BACKUP_FILE<<"\n";
    cout<<"Audio settings: "<<AUDIO_CONFIG_FILE<<"\n";
    while(running){Uint32 now=SDL_GetTicks();float dt=max(.001f,min(.033f,(now-prev)/1000.0f));prev=now;SDL_Event e;
        while(SDL_PollEvent(&e)){
            if(e.type==SDL_QUIT){running=false;break;}
            if(e.type==SDL_WINDOWEVENT &&
               (e.window.event==SDL_WINDOWEVENT_SIZE_CHANGED || e.window.event==SDL_WINDOWEVENT_RESIZED)){
                ConfigureLogicalViewport(r);
            }
            game.Event(window,r,e,audio);
        }
        if(!running)break;
        game.Update(dt,audio);
        Scene drawScene=game.scene;
        if(game.scene==Scene::TRANSITION)
            drawScene=game.transitionSwitched ? game.transitionTarget : game.transitionFrom;

        switch(drawScene){
            case Scene::MENU:DrawMenu(r,game,audio.IsMuted());break;
            case Scene::HOW_TO:DrawHowTo(r,audio.IsMuted());break;
            case Scene::SETTINGS:DrawSettings(r,audio);break;
            case Scene::LEVEL_SELECT:DrawLevelSelect(r,game.levels,game.progress,game.messageTimer,game.focusLevel,game.elapsed);break;
            case Scene::PLAYING:DrawGameplay(r,game,audio.IsMuted());break;
            case Scene::PLAYER_DYING:DrawDeath(r,game,audio.IsMuted());break;
            case Scene::PAUSED:DrawPaused(r,game,audio.IsMuted());break;
            case Scene::LEVEL_COMPLETE:DrawComplete(r,game,audio.IsMuted());break;
            case Scene::GAME_COMPLETE:DrawGameComplete(r,game);break;
            case Scene::TRANSITION:break;
        }

        if(game.scene==Scene::TRANSITION)
            DrawTransitionOverlay(r,game.TransitionAlpha());

        SDL_RenderPresent(r);SDL_Delay(1);
    }
    SDL_DestroyRenderer(r);SDL_DestroyWindow(window);audio.Shutdown();SDL_Quit();return 0;
}
